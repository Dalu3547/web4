const express = require("express");
const router = express.Router();
const Task = require("../models/Task");
const jwt = require("jsonwebtoken");

// Middleware to verify JWT
const authenticate = (req, res, next) => {
  let token = req.cookies.token || req.headers.authorization;
  console.log("🔍 Token received:", token);
  if (!token) return res.status(401).json({ error: "Access denied" });

  if (token.startsWith("Bearer ")) {
    token = token.split(" ")[1]; // Remove "Bearer " prefix
  }

  try {
    const verified = jwt.verify(token, process.env.JWT_SECRET);
    console.log("✅ Verified Token:", verified);
    req.user = verified;
    next();
  } catch (err) {
    console.log("❌ Invalid Token:", err.message);
    return res.status(400).json({ error: "Invalid token" });
  }

};


// Create a Task
router.post("/create", authenticate, async (req, res) => {
  const { title, description, status } = req.body;
  try {
    const task = new Task({ title, description, status, userId: req.user.userId });
    await task.save();
    res.json({ message: "Task created", task });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Get User's Tasks
router.get("/", authenticate, async (req, res) => {
  try {
    console.log("🔍 Fetching tasks for user:", req.user);
    const tasks = await Task.find({ userId: req.user.userId });
    console.log("✅ Tasks Found:", tasks);
    
    res.render("tasks", { tasks });  // Renders the tasks page
  } catch (err) {
    console.error("❌ Error fetching tasks:", err);
    res.status(500).send("Server Error");
  }
});



console.log("✅ Login Successful. Redirecting to /tasks...");
module.exports = router;
