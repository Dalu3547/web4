const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Register Page (Render EJS)
router.get("/register", (req, res) => {
  res.render("register");
});

// Login Page (Render EJS)
router.get("/login", (req, res) => {
  res.render("login");
});

// Register User (POST)
router.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  console.log("🔍 Register Request:", { name, email, password });

  let user = await User.findOne({ email });
  if (user) {
      console.log("❌ User Already Exists");
      return res.status(400).send("User already exists");
  }

  // ✅ Correctly Hash Password
  const hashedPassword = await bcrypt.hash(password, 10);
  console.log("✅ Hashed Password:", hashedPassword);

  user = new User({ name, email, password: hashedPassword });
  await user.save();

  console.log("✅ User Registered Successfully");
  res.redirect("/auth/login");
  
});


router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  console.log("🔍 Login Request:", { email, password });

  try {
      const user = await User.findOne({ email });
      if (!user) {
         console.log("❌ User Not Found");
          return res.send("<h2>Access Denied: User not found</h2><a href='/auth/login'>Try Again</a>");
      }
    

      console.log("🔑 Entered Password:", password);
      console.log("🔐 Stored Hashed Password:", user.password);

      const isPasswordValid = await bcrypt.compare(password, user.password);
      console.log("✅ Password Valid:", isPasswordValid);


      if (!isPasswordValid) {
          console.log("❌ Invalid Password");
          return res.send("<h2>Access Denied: Invalid password</h2><a href='/auth/login'>Try Again</a>");
      }

      // Generate JWT token
      const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
      console.log("✅ Token Generated:", token);

      // Store token in cookie
      res.cookie("token", token, { httpOnly: true, maxAge: 3600000 });
      console.log("✅ Token Set in Cookie:", token);
      // ✅ Redirect to tasks page
      res.redirect("/tasks");

  } catch (error) {
      console.error("❌ Server Error:", error);
      res.send("<h2>Server Error. Please try again later.</h2><a href='/auth/login'>Back to Login</a>");
  }
});
module.exports = router;
