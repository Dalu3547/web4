Task Manager Web App

Project Overview

This is a Task Manager Web Application built using:

Node.js and Express.js for the backend

EJS for dynamic HTML rendering

MongoDB for database storage

Mongoose for MongoDB object modeling

JWT Authentication for secure user access

Bcrypt for password hashing

The app allows users to register, log in, create, and manage tasks securely.

Features

User Authentication (Register and Login with hashed passwords)

Task Management (Create, View, and Manage tasks)

JWT-based Authentication (Secured API routes)

EJS Templates for Frontend Rendering

MongoDB Local Database Support

Installation and Setup

1. Download the Project Files

Ensure you have the project files available on your computer.

2. Install Dependencies

npm install

3. Configure Environment Variables

Create a .env file in the root folder and add:

MONGO_URI=mongodb://localhost:27017/mydatabase
JWT_SECRET=your_secret_key
PORT=5000

4. Start the Server

node server.js

Usage Guide

Open the Web App

Visit http://localhost:5000/ in your browser.

Register a New User

Go to http://localhost:5000/auth/register

Fill in your details and click Register

You will be redirected to the login page

Login

Go to http://localhost:5000/auth/login

Enter your credentials and click Login

You will receive a JWT token for authentication

Manage Tasks

After logging in, go to http://localhost:5000/tasks/

You can create, view, and manage tasks

API Endpoints

Method

Route

Description

GET  / Home Page

GET /auth/register Registration Page

POST  /auth/register  Register a new user

GET  /auth/login Login Page

POST /auth/login Authenticate user and return JWT

GET /tasks/  View all tasks (Authenticated)

POST  /tasks/create   Create a new task (Authenticated)

Troubleshooting

MongoDB Connection Issues

Ensure MongoDB is running locally.

Check .env file for the correct MONGO_URI.

Cannot POST /auth/register

Ensure routes/auth.js has the correct POST route.

Restart the server with:

node server.js

Mongoose Timeout Errors

Ensure mongod is running locally.

Submission Guidelines

ZIP the entire project.

Include .env.example (without real credentials).

Include screenshots if required.

Submit before the deadline.

Author

Tynybek Dalu and Khamit Nurdaulet - Astana IT University Date: 16th February 2025

